import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;

// panes og annet
import javafx.scene.layout.VBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.Region;
import javafx.geometry.Pos;
import javafx.scene.text.Text;
import javafx.scene.text.Font;
import javafx.scene.shape.Rectangle;
import javafx.scene.control.Button;
import javafx.scene.paint.Color;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.application.Platform;


public class Spill extends Application {

    private static final Scanner scanner = new Scanner(System.in);
    private static Terreng terreng;
    private static Spiller enkeltSpiller;


    private static void opprettTerreng(String steder, String gjenstander) {
        terreng = new Terreng(steder);
        terreng.fyllKister(gjenstander);
    }


    // for aa opprette en spiller
    private static void opprettSpiller(String navn, int antallTrekk) {
        Terminal brukerTerminal = new Terminal(scanner);

        Sted startSted = terreng.hentStart();
        Spiller spiller = new Spiller(navn, antallTrekk, brukerTerminal, startSted);
        brukerTerminal.settSpiller(spiller);

        enkeltSpiller = spiller;
    }

    // for aa opprette en robott
    private static void opprettRoboter(String navn, int antallTrekk) {
        Robot robot = new Robot();

        Sted startsted = terreng.hentStart();
        Spiller spiller = new Spiller(navn+"0", antallTrekk, robot, startsted);
        robot.settSpiller(spiller);

        enkeltSpiller = spiller;
    }

    // oppgave 3 - viser resultater i et GUI-vindu
    @Override
    public void start(Stage teater) {

        // hoeyde for brett
        int hoyde = 200;

        // oppretter og endrer Hoved-panen
        VBox root = new VBox();
        root.setAlignment(Pos.BASELINE_CENTER);
        root.setStyle("-fx-border-color: black; -fx-border-width: 2");

        // oppretter lyse-blaa bakgrunn og legger inn i stackpane
        StackPane skjerm = new StackPane();
            Rectangle r = new Rectangle(400,hoyde);
            r.setFill(Color.SKYBLUE);
        skjerm.getChildren().add(r);

        // oppretter en "header"
        VBox linje1 = new VBox(10); linje1.setAlignment(Pos.BASELINE_CENTER);
            Text beskrivelse = new Text(" - Resultatliste over skattjakten - ");
        beskrivelse.setFont(new Font(25));
        linje1.getChildren().add(beskrivelse);

        //stackpane for aa putte rektangel over tekst
        StackPane box = new StackPane();

            // oppretter rektangel
            Region rect = new Region();
            rect.setStyle("-fx-background-color: lightblue; -fx-border-style: solid; -fx-border-width: 3; -fx-border-color: black; -fx-max-width:335; -fx-max-height: 45;");

            // oppretter rekst for hver spiller
            String resultat = (enkeltSpiller.hentNavn() + " fikk " + enkeltSpiller.hentFormue() + " poeng");
            Text t = new Text(resultat);
            t.setFont(new Font(30));

        // setter rektangelet inn i stackpane med teksten over, og legger saa dette inn i linje1-VBox'en
        box.getChildren().addAll(rect, t);
        linje1.getChildren().add(box);


        /// oppretter den knapp og setter den nederst i Stackpanen
        Button b = new Button("Avslutt");
        b.setPrefWidth(400); b.setPrefHeight(30);
        b.setOnAction(new AvsluttBehandler());
        StackPane.setAlignment(b, Pos.BOTTOM_CENTER);

        // legger til linje1 (box>(rektangel og tekst) og knappen til skjerm, deretter alt dette til "root-panen" som vises
        skjerm.getChildren().addAll(linje1, b);
        root.getChildren().addAll(skjerm);

        Scene scene = new Scene(root);
        teater.setScene(scene);
        teater.setTitle("Resultater");
        teater.show();
    }

    public static void main(String[] args) {
        try {
            final String steder = args[0];
            final String gjenstander = args[1];
            final int maksAntallTrekk = Integer.parseInt(args[2]);

            opprettTerreng(steder, gjenstander);

            // for aa lage en vanlig spiller
            opprettSpiller("Arne", maksAntallTrekk);

            // for aa lage en robot
            // opprettRoboter("Robot", 2, maksAntallTrekk);

            Spiller SpillerEn = enkeltSpiller;

            while (SpillerEn.hentTrekk() > 0) {
                SpillerEn.nyttTrekk();
            }

            // starter avslutnings-nedtelling og starter GUI-vinduet
            Thread avslutter = new Thread(new AvsluttTraad());
            avslutter.start();
            launch(args);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("\n\nSpill maa ha argumentene: steder.txt gjenstander.txt antallMaksTrekk\n");
            System.exit(0);
        }
    }

    // avslutter ved knappetrykk
    static class AvsluttBehandler implements EventHandler<ActionEvent> {
        @Override
        public void handle(ActionEvent e) {
            Platform.exit();
        }
    }

    // avslutter etter 5 sekunder
    static class AvsluttTraad implements Runnable {

        @Override // kode som kjoeres av traad
        public void run() {
            try {
                Thread.sleep(5000);
                Platform.exit();
            } catch (InterruptedException e) {
                System.out.println(e.getMessage());
            }
        }
    }
}