
public class TraadRobot extends Robot {

    @Override
    public void giStatus() {
        // fjerner all printing i terminalen
    }
}